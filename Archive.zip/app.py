from flask import Flask, render_template, jsonify
import json

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/solo-tables')
def solo_tables():
    return render_template('solo-tables.html')

@app.route('/updates')
def updates():
    return render_template('updates.html')

@app.route('/api/medals', methods=['GET'])
def get_medals():
    with open('data/medals.json', 'r') as json_file:
        medals_data = json.load(json_file)
    return jsonify(medals_data)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
