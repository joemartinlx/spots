document.addEventListener('DOMContentLoaded', () => {
    const leagueTableBody = document.getElementById('league-table-body');
    const playerTables = document.getElementById('player-tables');
    const updatesFeed = document.getElementById('updates-feed');

    const players = [
        { name: "Joe", nations: ["Australia", "Japan", "France", "South Korea", "Azerbaijan", "Iraq", "Czech Republic", "Italy"] },
        { name: "Tim", nations: ["China", "USA", "Estonia", "Argentina", "Republic of Ireland", "Lebanon", "Ethiopia", "Kazakhstan"] },
        { name: "Leonie", nations: ["Bermuda", "Liechtenstein", "Switzerland", "Djibouti", "Uganda", "Peru", "Croatia", "Dominican Republic"] },
        { name: "Crumpy", nations: ["Venezuela", "Spain", "Andorra", "Tuvalu", "Guinea-Bissau", "North Korea", "Chile", "Columbia"] },
        { name: "Sam", nations: ["Maldives", "Mexico", "Greece", "Kenya", "Hungary", "Honduras", "India", "Denmark"] },
        { name: "Holly", nations: ["New Zealand", "Fiji", "Austria", "Norway", "Canada", "Malawi", "Germany", "Kosovo"] }
    ];

    function fetchMedalData() {
        return fetch('/api/medals')
            .then(response => response.json());
    }

    function calculateMedals(medalData, player) {
        const medalCount = { gold: 0, silver: 0, bronze: 0 };
        player.nations.forEach(nation => {
            const nationMedals = medalData[nation];
            if (nationMedals) {
                medalCount.gold += nationMedals.gold || 0;
                medalCount.silver += nationMedals.silver || 0;
                medalCount.bronze += nationMedals.bronze || 0;
            }
        });
        return medalCount;
    }

    function updateLeagueTable(medalData) {
        leagueTableBody.innerHTML = '';
        players.forEach(player => {
            const medals = calculateMedals(medalData, player);
            const totalPoints = (medals.gold * 3) + (medals.silver * 2) + (medals.bronze * 1);

            leagueTableBody.innerHTML += `
                <tr>
                    <td>${player.name}</td>
                    <td>${medals.gold}</td>
                    <td>${medals.silver}</td>
                    <td>${medals.bronze}</td>
                    <td>${totalPoints}</td>
                </tr>
            `;
        });
    }

    function updateSoloTables(medalData) {
        playerTables.innerHTML = '';
        players.forEach(player => {
            let tableContent = `
                <table>
                    <thead>
                        <tr>
                            <th colspan="3">${player.name}</th>
                        </tr>
                        <tr>
                            <th>Nation</th>
                            <th>Medal Type</th>
                            <th>Count</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            player.nations.forEach(nation => {
                const nationMedals = medalData[nation] || { gold: 0, silver: 0, bronze: 0 };
                tableContent += `
                    <tr>
                        <td>${nation}</td>
                        <td>Gold</td>
                        <td>${nationMedals.gold}</td>
                    </tr>
                    <tr>
                        <td>${nation}</td>
                        <td>Silver</td>
                        <td>${nationMedals.silver}</td>
                    </tr>
                    <tr>
                        <td>${nation}</td>
                        <td>Bronze</td>
                        <td>${nationMedals.bronze}</td>
                    </tr>
                `;
            });
            tableContent += `</tbody></table>`;
            playerTables.innerHTML += tableContent;
        });
    }

    function refreshData() {
        fetchMedalData().then(medalData => {
            updateLeagueTable(medalData);
            updateSoloTables(medalData);
        });
   
